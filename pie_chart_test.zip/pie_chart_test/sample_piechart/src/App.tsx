import React from "react";
import PieChart from "piechart2";

import logo from "./logo.svg";
import "./App.css";
import Dummy from "./Dummy.json";

function App() {
  return <PieChart size={500} chartData={Dummy.chartData} />;
}

export default App;
