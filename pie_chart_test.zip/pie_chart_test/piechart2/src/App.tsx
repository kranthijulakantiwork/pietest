import React from "react";
import "./App.css";
import styled from "styled-components";
import PieChart from "piechart2";

const PieChart = styled.div<{ size: number; chartData: string }>`
  width: ${(props) => props.size}px;
  height: ${(props) => props.size}px;
  border-radius: 50%;
  background-image: ${(props) => props.chartData};
`;

type Props = {
  size: number;
  data: { color: String; ratio: number }[];
};

function App(props: Props) {
  const { data, size } = props;
  let chartData: string = "conic-gradient(";
  let start = 0;
  data.forEach((share) => {
    chartData += `${share.color} ${start}deg, ${share.color} ${
      start + share.ratio * 360
    }deg, `;
    start += share.ratio * 360;
  });
  chartData = chartData.substring(0, chartData.length - 2);
  chartData += ")";

  return <PieChart chartData={chartData} size={size} />;
}

export default App;
